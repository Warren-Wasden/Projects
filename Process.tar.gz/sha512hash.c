/*
 * Warren Wasden
 * HW_1
 * CPSC_3220
 *
 * This program takes in one command line argument which is a word
 * and returns the hashed value of it using the sha512 hashing algorithm.
 * for the sha512 hash I will be using the crypt.h library and crypt() function.
 *
 * To compile this program you will need to include the -lcrypt flag:
 *
 * 	gcc sha512hash.c -o sha512hash -lcrypt
 *
 * This file will later be passed as an argument to a child function using the
 * exec call in asg1.c
 *
*/

#include <stdio.h>
#include <crypt.h>

int main(int argc, char* argv[])
{
	/*
	 * Take input from the file, call the crypt function and print output.
	*/

	char* input = argv[1];
	char* hash = crypt(input, "$6$");
	fprintf(stdout, "%s", hash);
 return 0;
}
