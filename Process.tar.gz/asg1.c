/*
 * Name:	Warren Wasden
 * Assignment:	HW_1
 * Class:	CPSC_3220
 * Professor:	Dr. Drachova
 * Date:	02/17/24
 *
 * This file will take an input word from the command line as well as a future date from
 * the command line.
 *
 * There will be two separate processes created using fork(). From
 * there the first child will execute the hashing of the input word that was passed
 * in from the command line using the SHA512 hasing algorithm and the crypt() function
 * from the crypt.h library. The first child will also print its own process ID as well
 * as its parents ID. 
 *
 * The second child will create a thread that will take the date struct and calculate
 * years months and days from the current date. The value of the struct will be returned
 * to the child process to print the values. 
 *
*/

#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <string.h>
#include <time.h>

typedef struct
{
	int month;
	int day;
	int year;
}Date;

// Void function that takes in a Date pointer argument, and augments that data to get
// the most recent current date.

void getCurrentDate(Date *currentDate) 
{
	// Using time.h to calculate the current date and assign the current date to the
	// currentDate pointer and update its values.
	time_t t = time(NULL);
	struct tm *local = localtime(&t);

    	if (local != NULL) 
    	{
        	currentDate->day = local->tm_mday;
	        currentDate->month = local->tm_mon + 1; // mon is 0-based
        	currentDate->year = local->tm_year + 1900; // year is years since 1900
	    } 
	    else 
    	{
        	perror("Failed to get current date");
	        exit(1);
    	}
}


// Easy helper function to test the input date to make sure it is a valid date

bool validDayInMonth(int d, int m, int y)
{
	if (d > 0)
	{
		if ((m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12)
			&& d <= 31)
		{
			return true;
		}
		else if ((m == 4 || m == 6 || m == 9 || m == 30) && d <= 30)
		{
			return true;
		}
		else if (m == 2)
			return (d <= 28);
	}
	return false;

}


// Function to make sure the date is a future date

bool validateDate(char* inputDate)
{
	// Get the current date
	Date currentDate;
	getCurrentDate(&currentDate);

	int day, month, year;
	sscanf(inputDate,"%d/%d/%d", &month, &day, &year);

	if (validDayInMonth(day, month, year))
	{
		// Compare input date with current date. If input date is a future date, then valid.
		if (year >= currentDate.year) 
		{
			if (year > currentDate.year) {return true;}
			if (year == currentDate.year && month > currentDate.month) {return true;}
			if (year == currentDate.year && month == currentDate.month && day >= currentDate.day)
			{
					return true;
			}
			
		}
	}
	return false;
}


// Thread function to calculate the amount of days, months, or years, until the future
// date that will be inputted through the command line or the user.

void* calculateTimeUntil(void* args)
{
	Date* date = (Date*) args;

	// Malloc for new date struct to store values
	Date* dateUntil = malloc(sizeof(Date));
	if (dateUntil == NULL) {
        	perror("Memory allocation failed");
        	exit(1);
    	}

	//copy input values to new DateUntil structure
	memcpy(dateUntil, date, sizeof(Date));

	// Struct to hold the value of the current date
	Date currentDate;

	// Function call to assign currentDate the correct current date value
	getCurrentDate(&currentDate);	


	// Calculate time until future date
	int yearsLeft = dateUntil->year - currentDate.year;
	int monthsLeft = dateUntil->month - currentDate.month;
	int daysLeft = dateUntil->day - currentDate.day;

	if (daysLeft < 0)
	{
		monthsLeft--;
		daysLeft += (dateUntil->month % 2 == 1 && dateUntil->month <= 7) ||
			(dateUntil->month % 2 == 0 && dateUntil->month >= 8) ? 31 : 30;
	}
	
	if (monthsLeft < 0)
	{
		yearsLeft--;
		monthsLeft += 12;
	}
	// Assign values to struct values to return to child process
	dateUntil->day = daysLeft;
	dateUntil->month = monthsLeft;
	dateUntil->year = yearsLeft;

	
	// Exit the thread and return the time from current date until future date.
	pthread_exit((void*)dateUntil);
}



int main(int argc, char* argv[])
{
	
	// Input validation if incorrect amount of command line arguments
	if (argc != 3)
	{
		// Variables for input and 3 time count
		char inputW[50];
		char inputD[10];
		int count = 0;

		while (count < 3)
		{
			printf("Invalid number of command line arguments.\n");
			printf("Enter the word_(space)_ date (mm/dd/yyyy): ");

			// Scanf to check for 2 arguments
			if (scanf("%s %s", inputW, inputD) == 2)
			{
				// Check for valid date
				if (validateDate(inputD))
				{
					// set argc to 3 for variable initialization
					argc = 3;
					argv[1] = inputW;
					argv[2] = inputD;
					break;
				}
			}


			// Finish reading the line until \n character is reached
			else
				while (getchar() != '\n');
				count++;
			if (count == 3)
			{
				printf("Max number of attempts. Exiting program.\n");
				return 0;
			}
		}
	}
	
	// Input validation for the date being incorrect but correct number
	// of command line arguments
	else
	{
		
		// Variables for input and 3 time count
		char *inputW = argv[1];
		char *inputD = argv[2];
		int count = 0;

		while (count < 3)
		{
			if (validateDate(inputD))
			{
				break;
			}

			printf("Invalid date.\n");
			printf("Enter the word_(space)_ date (mm/dd/yyyy): ");

			// Scanf to check for 2 arguments
			if (scanf("%s %s", inputW, inputD) == 2)
			{
				// Check for valid date
				if (validateDate(inputD))
				{
					// set argc to 3 for variable initialization
					argc = 3;
					argv[1] = inputW;
					argv[2] = inputD;
					break;
				}
			}

			// Finish reading the line until \n character is reached
			else
				while (getchar() != '\n');
				count++;
			if (count == 3)
			{
				printf("Max number of attempts. Exiting program.\n");
				return 0;
			}
		}
	}
	char* word = argv[1];
	char* date = argv[2];



	// Create date struct from date string from command line.
	// This will be used in the second child fork();
	Date validDate;
	validDate.month = 0;
	validDate.day = 0;
	validDate.year = 0;
	sscanf(date,"%d/%d/%d", &validDate.month, &validDate.day, &validDate.year);

	// Create variables for Child process IDs going to be created from fork
	pid_t c1_PID, c2_PID;

	// First child fork
	c1_PID = fork();
	if (c1_PID == 0)
	{
		// Printing information for the first child process
		printf("Child 1: pid  %d, ppid: %d", getpid(), getppid());
		printf(", SHA512 of %s is ", word);
		
		// make sure the output is flushed
		fflush(stdout);

		// Exec call to run another file with a program to accomplish the SHA512
		// hashing algorithm.
		execl("./sha512hash", "sha512hash", word, NULL);
		perror("\nexecl failed.\n");
		exit(0);
	}

	// If not child ID exit
	else if (c1_PID < 0)
	{
		perror("Did not fork!\n");
		exit(1);
	}

	// wait call for the fork to finish before continuing
	waitpid(c1_PID, NULL, 0);

	// Create second Date pointer to store the values from thread return call
	Date* newDateUntil;

	// Second child fork
	c2_PID = fork();
	if (c2_PID == 0)
	{
		

		// Print second child info
		printf("\nChild2: pid = %d, ppid = %d\n", getpid(), getppid());

		// Create Thread ID variable
		pthread_t threadID;

		// Create a new thread
		pthread_create(&threadID, NULL, calculateTimeUntil, (void*) &validDate);

		// Join the thread back to the main program
		if (pthread_join(threadID, (void**)&newDateUntil) != 0)
		{
			perror("Error joining thread!\n");
			exit(1);
		}
		else
		
			// Print thread ID values and time until future date
			threadID = pthread_self();
			printf("\tThread1: tid = %lu\n", (unsigned long) threadID);
			printf("\tTime until %02d/%02d/%d is %d days,%d months, and %d years\n",
				validDate.month, validDate.day, validDate.year,
				newDateUntil->day, newDateUntil->month, newDateUntil->year);

			free(newDateUntil);
	}

	// If not child ID exit
	else if (c2_PID < 0)
	{
		perror("Did not fork!\n");
		exit(1);
	}

	// wait call for the fork to finish before continuing
	waitpid(c2_PID, NULL, 0);
	
	return 0;
}
